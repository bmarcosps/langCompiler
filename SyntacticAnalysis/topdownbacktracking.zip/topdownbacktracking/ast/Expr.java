package ast;

/*
 * Esta classe representa um comando de Impressão.
 * Expr
 */
public abstract class Expr extends Node {
      
      public Expr(int l, int c){
           super(l, c);
      }
      

      
}
