package parser;

import java.util.Stack;
import java.util.LinkedList;
import java.io.FileReader;
import java.io.IOException;
import ast.*;

public class LangParser3 extends  TopDownRecursiveParser{
      
      public LangParser3(String fileName) throws IOException{
          super(fileName);
      }
      
      public Node prog() throws IOException{
                Node list = null;
                
                if(stmtList() && eof){
                    list = ast.peek();
                }
                
                System.out.println("Last: " + nxt);
                System.out.println("Remaining input: ");
                
                while(nxt != null ){
                    System.out.println("" + nxt);
                    readToken();
                }
                
                System.out.println("EOF status: " + eof);
                return list;
      }
      
      public boolean stmtList() throws IOException{
          int n = stk.size();
          int k = ast.size();
          if(stmt()){
              int x = getCurrLine() ;
              int y = getCurrCol() ; 
              if(match(TOKEN_TYPE.SEMI)){
                  if(stmtList()){
                     Node list = ast.pop();
                     Node stmt = ast.pop();
                     Node stmtl = new StmtList(x, y, stmt, list);
                     ast.push(stmtl);   
                     System.out.println("putting CmdList: " + stmt + ",  " + list);
                     return true;
                  }
              }
          }
          
          backtrack(stk.size() - n,ast.size() - k);
          
          if(stmt()){
              if(match(TOKEN_TYPE.SEMI)){
                  System.out.println("putting Stmt: " + ast.peek());
                  return true;
              }
          }
          backtrack(stk.size() - n,ast.size() - k);
          
          return false;
      }
      
      public boolean stmt() throws IOException{
          int n = stk.size();
          int k = ast.size();
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          if(match(TOKEN_TYPE.ID)){
              ast.push(new ID(x,y,stk.peek().lexeme));
              if(match(TOKEN_TYPE.EQ)){
                  if(exp()){
                     Node exp = ast.pop();
                     Attr att = new Attr(x, y, (ID)ast.pop(), (Expr)exp);
                     ast.push(att);
                     System.out.println("putting " + ast.peek());
                     return true;
                  }
              }
          }
          backtrack(stk.size() - n,ast.size() - k);
          if(exp()){
             Print p = new Print(x,y,(Expr)ast.pop());
             ast.push(p);
             System.out.println("putting Print " + ast.peek());
             return true;
          }
          backtrack(stk.size() - n,ast.size() - k);
          return false;
      }
      
      public boolean exp() throws IOException{
          int n = stk.size();
          int k = ast.size();
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          if(match(TOKEN_TYPE.ID)){
              ast.push(new ID(x,y,stk.peek().lexeme));
              System.out.println("putting " + ast.peek());
              if(exp1()){
                 return true;
              }
          }
          backtrack(stk.size() - n,ast.size() - k);
          if(match(TOKEN_TYPE.NUM)){
              ast.push(new Num(x,y,(Integer)stk.peek().info));
               System.out.println("putting " + ast.peek());
              if(exp1()){
                 return true;
              }
          }
          backtrack(stk.size() - n,ast.size() - k);
          return false;
      }
      
      public boolean exp1() throws IOException{
          int n = stk.size();
          int k = ast.size();
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          
          if(match(TOKEN_TYPE.PLUS)){
              if(exp()){
                  Expr rgt = (Expr)ast.pop();
                  Expr lft = (Expr)ast.pop();
                  System.out.println("putting Add " + rgt + ", " + lft);
                  ast.push(new Add(x,y,lft,rgt));
                  if(exp1()){
                     return true;
                  }
              }
          }
          backtrack(stk.size() - n,ast.size() - k);
          
          if(match(TOKEN_TYPE.TIMES)){
              if(exp()){
                  Expr rgt = (Expr)ast.pop();
                  Expr lft = (Expr)ast.pop();
                  ast.push(new Mul(x,y,lft,rgt));
                  System.out.println("putting Mul " + rgt + ", " + lft);
                  if(exp1()){
                     return true;
                  }
              }
          } 
          
          backtrack(stk.size() - n,ast.size() - k);
          
          return true; // devemos sempre retonar true ?           
      }
      
}
