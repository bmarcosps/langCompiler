package parser;

import java.util.Stack;
import java.util.LinkedList;
import java.io.FileReader;
import java.io.IOException;
import ast.*;

public class MiniLangParser extends TopDownPredictiveParser{
      
      public MiniLangParser(String fileName) throws IOException{
          super(fileName);
      }
      
      public Node prog() throws IOException{
                // Prog -> StmtList 
                Node list = null;
                
                if(stmtList() && eof){
                    list = ast.peek();
                }
                
                System.out.println("Last: " + nxt);
                System.out.println("Remaining input: ");
                
                while(nxt != null && !eof  ){
                    System.out.println("" + nxt);
                    readToken();
                }
                
                System.out.println("EOF status: " + eof);
                return list;
      }
      
      public boolean stmtList() throws IOException{
          // StmtList -> Stmt ; SList
          if(stmt()){
              int x = getCurrLine() ;
              int y = getCurrCol() ; 
              if(match(TOKEN_TYPE.SEMI)){
                  if(eof || nxt.t == TOKEN_TYPE.RB || nxt.t == TOKEN_TYPE.COLON){ return true;}
                  if(sList()){
                     Node list = ast.pop();
                     Node stmt = ast.pop();
                     Node stmtl = new StmtList(x, y, stmt, list);
                     ast.push(stmtl);   
                     return true;
                  }
              }
              else{ errMsg(";");}
          }
          return false;
      }
      
      public boolean sList() throws IOException{
          // SList -> Stmt ; SList
          if(nxt.t == TOKEN_TYPE.ID || nxt.t == TOKEN_TYPE.NUM || nxt.t == TOKEN_TYPE.AP){
              if(stmt()){
                  int x = getCurrLine() ;
                  int y = getCurrCol() ; 
                  if(match(TOKEN_TYPE.SEMI)){
                      if(eof || nxt.t == TOKEN_TYPE.RB || nxt.t == TOKEN_TYPE.COLON){ return true;}
                      if(sList()){
                         Node list = ast.pop();
                         Node stmt = ast.pop();
                         Node stmtl = new StmtList(x, y, stmt, list);
                         ast.push(stmtl);   
                         return true;
                      }
                  }else{ errMsg(";");}
              }
          }else if( eof || nxt.t == TOKEN_TYPE.COLON || nxt.t == TOKEN_TYPE.RB){
              return true;
          }else{ errMsg(": ou ]");}
          return false;
      }
      
      
      public boolean stmt() throws IOException{
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          // Stmt -> ID Stmt'
          if(match(TOKEN_TYPE.ID)){
              ast.push(new ID(x,y,lst.lexeme));
              if(stmt1()){
                     return true;
              }
          }
          // Stmt -> NUM Stmt'
          if(match(TOKEN_TYPE.NUM)){
                ast.push(new Num(x,y,(Integer)lst.info));
                if(exp1()){
                    return true;              
                }
          }
          // Stmt -> FParen Expr' 
          if(fParen()){
              if(exp1()){
                 return true;
              }
          }
          return false;
      }
 
      public boolean stmt1() throws IOException{
          // Stmt' -> = Exp
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          
          if(match(TOKEN_TYPE.EQ)){
              if(exp()){
                     Expr e = (Expr)ast.pop();
                     ID var = (ID)ast.pop();
                     ast.push(new Attr(x,y,var,e));
                     return true;
              }
              return false;
          }
          // Stmt' -> exp'
          if(exp1()){
               if(nxt.t == TOKEN_TYPE.IF){
                   if(thn()){
                       return true;
                   }
                   return false;
               }else{
                   Expr e = (Expr)ast.pop();
                   ast.push(new Print(x,y,e));
                   return true;              
               } 
          }
          return false;
      }
      
      public boolean thn() throws IOException{
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          // thn -> ? [ StmtList Els ]
          if(match(TOKEN_TYPE.IF)){
             if(match(TOKEN_TYPE.LB)){
                 if(stmtList()){
                    if(nxt.t == TOKEN_TYPE.COLON){
                       if(els()){
                          if(match(TOKEN_TYPE.RB)){
                             Node ne = ast.pop();
                             Node nt = ast.pop();
                             Expr t = (Expr)ast.pop();
                             ast.push(new If(x,y,t,nt,ne));
                             return true;
                          }
                          errMsg("]");
                          return false;
                       }
                    }else{
                       if(match(TOKEN_TYPE.RB)){
                          Node n = ast.pop();
                          Expr t = (Expr)ast.pop();
                          ast.push(new If(x,y,t,n));
                          return true;
                       }
                    }
                 }
             }
             errMsg("[");
             return false;
          }
          // thn -> Epsilon
          else if (nxt.t == TOKEN_TYPE.SEMI){
              return true;
          }
          errMsg("? ou ;");
          return false;
      }
      
      public boolean els() throws IOException {
          // els -> : StmtList
          if(match(TOKEN_TYPE.COLON)){
              if(stmtList()){
                  return true;
              }
              errMsg("StmtList");
              return false;
          }
          // els -> Epsilon
          if(nxt.t == TOKEN_TYPE.RB){
              return true;
          }
          errMsg(": ou ]");
          return false;
      }
      
      public boolean exp() throws IOException{
          // Exp ->  Term Exp'
          if(term()){
             return exp1();    
          }
          errMsg("ID,NUM ou (");
          return false;
      }
      
      public boolean exp1() throws IOException{
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          // Exp -> + Term Exp'
          if(match(TOKEN_TYPE.PLUS)){
              if(term()){
                 Expr er = (Expr)ast.pop();
                 Expr ee = (Expr)ast.pop();
                 ast.push(new Add(x,y,ee,er));
                 if(exp1()){
                    return true;
                 }
              }
              return false;
          }
          // Exp -> Epsilon
          else if(nxt.t == TOKEN_TYPE.IF || nxt.t == TOKEN_TYPE.SEMI || nxt.t == TOKEN_TYPE.FP ){
             return true;
          }else{  errMsg("+,?,; ou )");}
          return false;
      }
      
      public boolean term() throws IOException{
          // Term -> Fator Term'
          if(fator()){
             return term1();    
          }
          return false;
      }
      
      public boolean term1() throws IOException{
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          // Term' -> * Fator Term'
          if(match(TOKEN_TYPE.TIMES)){
              if(fator()){
                 Expr er = (Expr)ast.pop();
                 Expr ee = (Expr)ast.pop();
                 ast.push(new Mul(x,y,ee,er));
                 if(term1()){
                    return true;
                 }
              }
              errMsg("*");
              return false;
          }
          // Term' -> * Fator Term'
          else if(nxt.t == TOKEN_TYPE.IF || nxt.t == TOKEN_TYPE.SEMI || nxt.t == TOKEN_TYPE.FP || nxt.t == TOKEN_TYPE.PLUS ){
             return true;
          }else{ errMsg("?,;,) ou +");}
          return false;
      }
      
      
      public boolean fator() throws IOException{
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          // Fator -> ID
          if(match(TOKEN_TYPE.ID)){
              ast.push(new ID(x,y,lst.lexeme));
              return true;
          }
          // Fator -> NUM
          if(match(TOKEN_TYPE.NUM)){
              ast.push(new Num(x,y,(Integer)lst.info));
              return true;
          }
          // Fator -> FParen
          if(fParen()){
             return true;
          }
          errMsg("ID,NUM ou (");
          return false;
      }
      
      public boolean fParen() throws IOException {
         // FPare -> ( Exp )
         if(match(TOKEN_TYPE.AP)){
             if(exp()){
                 if(match(TOKEN_TYPE.FP)){
                     return true;
                 }
             }
         }
         return false;
      }
}


