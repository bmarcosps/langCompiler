package parser;

public enum TOKEN_TYPE {
    ID,
    NUM,
    EQ,
    PLUS,
    TIMES,
    IF,
    COLON,
    SEMI,
    RB,
    LB,
    AP,
    FP,
    EOF
}
