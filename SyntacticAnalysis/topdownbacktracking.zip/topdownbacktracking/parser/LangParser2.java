package parser;

import java.util.Stack;
import java.util.LinkedList;
import java.io.FileReader;
import java.io.IOException;

public class LangParser2 extends  TopDownRecursiveParser{
      
      public LangParser2(String fileName) throws IOException{
          super(fileName);
      }
      
      public boolean prog() throws IOException{
                msg("prog");
                incS();
                boolean result = stmtList() && eof;
                
                System.out.println("Last: " + nxt);
                System.out.println("Remaining input: ");
                
                while(nxt != null ){
                    System.out.println("" + nxt);
                    readToken();
                }
                
                System.out.println("EOF status: " + eof);
                return result;
      }
      
      public boolean stmtList() throws IOException{
          int n = stk.size();
          msg("stmtList -> stmt ; stmtList");
          incS();
          if(stmt()){
              if(match(TOKEN_TYPE.SEMI)){
                  if(stmtList()){
                     decS();
                     msg("[ok]");
                     return true;
                  }
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[Backtrack] stmtList -> stmt ;");
          incS();
          if(stmt()){
              if(match(TOKEN_TYPE.SEMI)){
                  decS();
                  msg("[ok]");
                  return true;
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[falhou]");
          return false;
      }
      
      public boolean stmt() throws IOException{
          int n = stk.size();
          msg("stmt -> ID = Exp");
          incS();
          if(match(TOKEN_TYPE.ID)){
              if(match(TOKEN_TYPE.EQ)){
                  if(exp()){
                     decS();
                     msg("[ok]");
                     return true;
                  }
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[backtracking]: stmt -> Exp");
          incS();
          if(exp()){
             decS();
             msg("[ok]");
             return true;
          }
          backtrack(stk.size() - n);
          decS();
          msg("[falhou]");
          return false;
      }
      
      public boolean exp() throws IOException{
          int n = stk.size();
          msg("exp -> (NUM|ID) exp1");
          incS();
          if(match(TOKEN_TYPE.ID) || match(TOKEN_TYPE.NUM)){
              if(exp1()){
                 decS();
                 msg("[ok]");
                 return true;
                 
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[falhou]");
          return false;
      }
      
      public boolean exp1() throws IOException{
          msg("exp1 -> (+|*) exp exp1");
          incS();
          int n = stk.size();
          if(match(TOKEN_TYPE.PLUS) || match(TOKEN_TYPE.TIMES)){
              if(exp()){
                  if(exp1()){
                     decS();
                     msg("[ok]");
                     return true;
                  }
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[ok]");
          return true; // devemos sempre retonar true ?           
      }
      
}
