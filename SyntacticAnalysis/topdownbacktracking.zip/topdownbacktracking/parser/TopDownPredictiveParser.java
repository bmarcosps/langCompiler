package parser;

import java.util.Stack;
import java.util.LinkedList;
import java.io.FileReader;
import java.io.IOException;
import ast.*;

public abstract class TopDownPredictiveParser {
      
      private LexTest lx;
      protected Stack<Node> ast;
      protected Token nxt;
      protected Token lst;
      protected boolean eof;
      
      
      //-- Apenas para propósitos de depuração:
      public String idnt;
      public void incS(){ idnt += "    ";}
      public void decS(){ idnt = idnt.substring(0,idnt.length() - 4);}
      
      private void msg(String s){
          System.out.println(idnt + s + " [>|" + nxt + " ]");
      }
      protected void tryAlt(String body){
           msg("Regra: " + body);
           incS();
      }
      protected void success(){
           decS();
           msg("[OK]");
      }
      protected void fail(){
           decS();
           msg("[Falhou]");
      }
      protected void errMsg(String expected){
           System.err.println("( " + nxt.l + "," + nxt.c + ") Esperando: \"" + expected + "\" Lido: \"" + nxt.t + "\"" );
      }
     
      public TopDownPredictiveParser(String fileName) throws IOException{
          lx = new LexTest(new FileReader(fileName));
          ast = new Stack<Node>();
          nxt = lx.nextToken();
          eof = (nxt == null) || (nxt.t == TOKEN_TYPE.EOF);
          idnt = "";
      }
      
      protected void readToken() throws IOException{
          if(!eof){
              nxt = lx.nextToken();
              eof = (nxt == null) || (nxt.t == TOKEN_TYPE.EOF);
          }
      }
      
      protected int getCurrLine(){ return nxt == null ? -1 : nxt.l; }
      protected int getCurrCol(){ return nxt == null ? -1 : nxt.c; }
      
      protected boolean match(TOKEN_TYPE t) throws IOException {
           if(nxt != null && nxt.t == t){
               lst = nxt;
               readToken();
               return true;
           }
           return false;
      }
      
}
