package parser;

import java.util.Stack;
import java.util.LinkedList;
import java.io.FileReader;
import java.io.IOException;
import ast.*;

public class LangParser4 extends  TopDownRecursiveParser{
      
      public LangParser4(String fileName) throws IOException{
          super(fileName);
      }
      
      public Node prog() throws IOException{
                Node list = null;
                
                if(stmtList() && eof){
                    list = ast.peek();
                }
                
                System.out.println("Last: " + nxt);
                System.out.println("Remaining input: ");
                
                while(nxt != null ){
                    System.out.println("" + nxt);
                    readToken();
                }
                
                System.out.println("EOF status: " + eof);
                return list;
      }
      
      public boolean stmtList() throws IOException{
          int n = stk.size();
          int k = ast.size();
          if(stmt()){
              int x = getCurrLine() ;
              int y = getCurrCol() ; 
              if(match(TOKEN_TYPE.SEMI)){
                  if(stmtList()){
                     Node list = ast.pop();
                     Node stmt = ast.pop();
                     Node stmtl = new StmtList(x, y, stmt, list);
                     ast.push(stmtl);   
                     System.out.println("putting CmdList: " + stmt + ",  " + list);
                     return true;
                  }
              }
          }
          
          backtrack(stk.size() - n,ast.size() - k);
          
          if(stmt()){
              if(match(TOKEN_TYPE.SEMI)){
                  System.out.println("putting Stmt: " + ast.peek());
                  return true;
              }
          }
          backtrack(stk.size() - n,ast.size() - k);
          
          return false;
      }
      
      public boolean stmt() throws IOException{
          int n = stk.size();
          int k = ast.size();
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          if(match(TOKEN_TYPE.ID)){
              ast.push(new ID(x,y,stk.peek().lexeme));
              if(match(TOKEN_TYPE.EQ)){
                  if(exp()){
                     Node exp = ast.pop();
                     Attr att = new Attr(x, y, (ID)ast.pop(), (Expr)exp);
                     ast.push(att);
                     return true;
                  }
              }
          }

          backtrack(stk.size() - n,ast.size() - k);
          if(fator()){
             if(match(TOKEN_TYPE.IF)){
                if(stmt()){
                    if(match(TOKEN_TYPE.COLON) ){
                        if(stmt()){
                           Node els = ast.pop();
                           Node thn = ast.pop();
                           Node ft = ast.pop();
                           If node = new If(x, y, (Expr)ft,thn,els);
                           ast.push(node);
                           return true;
                        }
                    }
                }
            }
          }

          backtrack(stk.size() - n,ast.size() - k);
          if(fator()){
             if(match(TOKEN_TYPE.IF)){
                if(stmt()){
                           Node thn = ast.pop();
                           Node ft = ast.pop();
                           If node = new If(x, y, (Expr)ft,thn);
                           ast.push(node);
                           return true;
                }
            }
          }
          
          backtrack(stk.size() - n,ast.size() - k);
          if(exp()){
             Print p = new Print(x,y,(Expr)ast.pop());
             ast.push(p);
             return true;
          }
          backtrack(stk.size() - n,ast.size() - k);
          return false;
      }
      
      public boolean exp() throws IOException{
         // exp -> fator + exp()
          int n = stk.size();
          int k = ast.size();
          int x = getCurrLine() ;
          int y = getCurrCol();
          if(fator()){
              x = getCurrLine() ;
              y = getCurrCol();
              if(match(TOKEN_TYPE.PLUS)){
                  if(exp()){
                     Expr el = (Expr)ast.pop();
                     Expr er = (Expr)ast.pop();
                     ast.push(new Add(x,y,el,er));
                     return true;
                  }
               }
          }
          
          backtrack(stk.size() - n,ast.size() - k);
          if(fator()){
              x = getCurrLine() ;
              y = getCurrCol();
              if(match(TOKEN_TYPE.TIMES)){
                  if(exp()){
                     Expr el = (Expr)ast.pop();
                     Expr er = (Expr)ast.pop();
                     ast.push(new Mul(x,y,el,er));
                     return true;
                  }
               }
          }
          
          backtrack(stk.size() - n,ast.size() - k);
          
          if(fator()){
             return true;
          }
          backtrack(stk.size() - n,ast.size() - k);
          return false;
      }
      
      public boolean fator() throws IOException{
          int n = stk.size();
          int k = ast.size();
          int x = getCurrLine() ;
          int y = getCurrCol() ; 
          if(match(TOKEN_TYPE.ID)){
              ast.push(new ID(x,y,stk.peek().lexeme));
              return true;
          }
          backtrack(stk.size() - n,ast.size() - k);
          
          if(match(TOKEN_TYPE.NUM)){
              
              ast.push(new Num(x,y,(Integer)stk.peek().info));
              return true;
          }
          backtrack(stk.size() - n,ast.size() - k);
          return false;
      }     
}
