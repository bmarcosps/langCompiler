package parser;

import java.util.Stack;
import java.util.LinkedList;
import java.io.FileReader;
import java.io.IOException;

public class LangParser extends TopDownRecursiveParser{
      
      public LangParser(String fileName) throws IOException{
          super(fileName);
      }
      
      public boolean prog() throws IOException{
                msg("prog");
                incS();
                boolean result = stmtList() && eof;
                
                System.out.println("Last: ");
                System.out.println("Remaining input: ");
                
                while(nxt != null ){
                    System.out.println("" + nxt);
                    readToken();
                }
                
                System.out.println("EOF status: " + eof);
                return result;
      }
      
      public boolean stmtList() throws IOException{
          int n = stk.size();
          msg("stmtList -> stmt ; stmtList");
          incS();
          if(stmt()){
              if(match(TOKEN_TYPE.SEMI)){
                  if(stmtList()){
                     decS();
                     msg("[ok]");
                     return true;
                  }
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[Backtrack] stmtList -> stmt ;");
          incS();
          if(stmt()){
              if(match(TOKEN_TYPE.SEMI)){
                  decS();
                  msg("[ok]");
                  return true;
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[falhou]");
          return false;
      }
      
      public boolean stmt() throws IOException{
          int n = stk.size();
          msg("stmt -> ID = Exp");
          incS();
          if(match(TOKEN_TYPE.ID)){
              if(match(TOKEN_TYPE.EQ)){
                  if(exp()){
                     decS();
                     msg("[ok]");
                     return true;
                  }
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[backtracking]: stmt -> Exp");
          incS();
          if(exp()){
             decS();
             msg("[ok]");
             return true;
          }
          backtrack(stk.size() - n);
          decS();
          msg("[falhou]");
          return false;
      }
      
      public boolean exp() throws IOException{
          int n = stk.size();
          msg("exp -> exp + exp ");
          incS();
          if(exp()){
              if(match(TOKEN_TYPE.PLUS)){
                 if(exp()){
                    decS();
                    msg("[ok]");
                    return true;
                 }
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[bactrcking]: exp -> exp * exp ");
          incS();
          if(exp()){
              if(match(TOKEN_TYPE.TIMES)){
                 if(exp()){
                    decS();
                    msg("[ok]");
                    return true;
                 }
              }
          }
          backtrack(stk.size() - n);
          decS();
          msg("[bactrcking]: exp -> ID ");
          if(match(TOKEN_TYPE.ID)){
                  decS();
                  msg("[ok]");
                  return true;
          }
          backtrack(stk.size() - n);
          decS();
          msg("[bactrcking]: exp -> NUM ");
          if(match(TOKEN_TYPE.NUM)){
                  decS();
                  msg("[ok]");
                  return true;
          }
          return false;
      }
      
}
