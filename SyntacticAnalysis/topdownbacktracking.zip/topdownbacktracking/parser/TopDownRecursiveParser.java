package parser;

import java.util.Stack;
import java.util.LinkedList;
import java.io.FileReader;
import java.io.IOException;
import ast.*;

public abstract class TopDownRecursiveParser {
      
      private LexTest lx;
      protected Stack<Token> stk;
      protected Stack<Node> ast;
      private LinkedList<Token> bck;
      protected Token nxt;
      protected boolean eof;
      
      
      //-- Apenas para propósitos de depuração:
      protected String idnt;
      protected void incS(){ idnt += "    ";}
      protected void decS(){ idnt = idnt.substring(0,idnt.length() - 4);}
      protected void msg(String s){
          System.out.println(idnt + s + " [>|" + nxt + " ]");
      }
      protected void tryAlt(String body){
           msg("Tentando " + body);
           incS();
      }
      protected void retryAlt(String body){
           decS();
           msg("Backtrack: " + body);
           incS();
      }
      protected void success(){
           decS();
           msg("[OK]");
      }
      protected void fail(){
           decS();
           msg("[Falhou]");
      }
     
      public TopDownRecursiveParser(String fileName) throws IOException{
          lx = new LexTest(new FileReader(fileName));
          stk = new Stack<Token>();
          ast = new Stack<Node>();
          bck = new LinkedList<Token>();
          nxt = lx.nextToken();
          eof = nxt == null;
          idnt = "";
      }
      
      protected void readToken() throws IOException{
          if(!eof){
             stk.push(nxt);
             if(bck.isEmpty()){
                 nxt = lx.nextToken();
                 eof = nxt == null;
             }else{
                 nxt = bck.remove();
             }
          }
      }
      
      protected void backtrack(int n, int k) throws IOException{
          if(n > 0 && nxt == null){ 
              nxt = stk.pop(); 
              n--; 
              eof = false;
          } 
          while(n > 0){ 
               bck.addFirst(nxt);
               nxt = stk.pop();
               n--;
          }
          if(!bck.isEmpty()){ eof = false;}
          while(k > 0){
             ast.pop();
             k--;
          }
      }
      
      protected void backtrack(int n) throws IOException{
          if(n > 0 && nxt == null){ 
              nxt = stk.pop(); 
              n--; 
              eof = false;
          } 
          while(n > 0){ 
               bck.addFirst(nxt);
               nxt = stk.pop();
               n--;
          }
          if(!bck.isEmpty()){ eof = false;}
      }
      
      protected int getCurrLine(){ return nxt == null ? -1 : nxt.l; }
      protected int getCurrCol(){ return nxt == null ? -1 : nxt.c; }
      
      protected boolean match(TOKEN_TYPE t) throws IOException {
           if(nxt != null && nxt.t == t){
               readToken();
               return true;
           }
           return false;
      }
      
}
